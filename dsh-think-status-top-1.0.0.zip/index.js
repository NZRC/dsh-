/**
 * Host half of @local/dsh-think-status-top.
 *
 * The placement is a browser-only surface: every behaviour lives in the client
 * module, which the harness's client module system loads from this package's
 * `dsh.client` declaration. The host half therefore has nothing to do, but the
 * package must still export `apply` so it composes as a Cordis plugin and shows
 * up in the loader.
 */
export function apply() {}