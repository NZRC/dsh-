# Install (or remove) the "thinking status stays on top" placement fix in a DSH profile.
#
# The fix is a browser-only DSH client plugin, so installing it means three edits:
#   1. declare this package as a profile dependency (file: this checkout),
#   2. materialise it with pnpm so node_modules carries it,
#   3. mount it by appending its name to dsh.profile.bundles.
#
# Ordering matters: `pnpm install` rewrites the profile manifest and drops
# third-party bundles, so the package tree is installed first and the bundle entry
# is written last, with nothing touching the manifest afterwards.
#
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1 -DryRun
#   powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1 -Uninstall
#
# Nothing is hard-coded to one machine or account: the profile directory, the node
# and pnpm the desktop app carries, and this checkout's own location are all
# discovered. Pass -Profile / -Source / -Node / -Pnpm to override detection.
#
# Keep this file ASCII-only. Windows PowerShell 5.1 reads a BOM-less .ps1 as ANSI,
# so non-ASCII literals here would print mojibake. The plugin's own copy stays
# localized because it is mirrored from the running row, not authored here.
param(
  [string]$Profile,
  [string]$Source,
  [string]$Node,
  [string]$Pnpm,
  [switch]$DryRun,
  [switch]$Uninstall
)

$ErrorActionPreference = 'Stop'

$plugin = '@local/dsh-think-status-top'

function Resolve-ProfileDir {
  if ($Profile) {
    if (-not (Test-Path (Join-Path $Profile 'package.json'))) { throw "-Profile has no package.json: $Profile" }
    return (Resolve-Path -LiteralPath $Profile).Path
  }
  if ($env:DSH_PROFILE_DIR) {
    if (-not (Test-Path (Join-Path $env:DSH_PROFILE_DIR 'package.json'))) { throw "DSH_PROFILE_DIR has no package.json: $env:DSH_PROFILE_DIR" }
    return (Resolve-Path -LiteralPath $env:DSH_PROFILE_DIR).Path
  }
  $root = Join-Path $env:USERPROFILE '.dsh\profiles'
  if (Test-Path $root) {
    foreach ($name in @('desktop', 'web')) {
      $candidate = Join-Path $root $name
      if (Test-Path (Join-Path $candidate 'package.json')) { return $candidate }
    }
    $found = @(Get-ChildItem -LiteralPath $root -Directory -ErrorAction SilentlyContinue |
      Where-Object { Test-Path (Join-Path $_.FullName 'package.json') })
    if ($found.Count -eq 1) { return $found[0].FullName }
  }
  throw 'no DSH profile found; pass -Profile <profile dir> (for example %USERPROFILE%\.dsh\profiles\desktop)'
}

function Resolve-SourceDir {
  if ($Source) {
    if (-not (Test-Path (Join-Path $Source 'package.json'))) { throw "-Source has no package.json: $Source" }
    return (Resolve-Path -LiteralPath $Source).Path
  }
  if ($PSScriptRoot) { return (Resolve-Path -LiteralPath $PSScriptRoot).Path }
  return (Resolve-Path -LiteralPath '.').Path
}

function Resolve-NodeExe {
  $candidates = @()
  if ($Node) { $candidates += $Node }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe'),
    (Join-Path $env:USERPROFILE '.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\node\bin\node.exe'),
    (Join-Path $env:ProgramFiles 'DeepSeek Harness\resources\runtime\primary-runtime\dependencies\node\bin\node.exe')
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path $candidate)) { return $candidate }
  }
  $onPath = Get-Command node -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw 'no node runtime found; pass -Node <node.exe>'
}

function Resolve-Pnpm {
  $candidates = @()
  if ($Pnpm) { $candidates += $Pnpm }
  $candidates += @(
    (Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\pnpm\bin\pnpm.mjs'),
    (Join-Path $env:USERPROFILE '.dsh\dsh-runtimes\dsh-primary-runtime\dependencies\pnpm\bin\pnpm.mjs'),
    (Join-Path $env:LOCALAPPDATA 'Programs\DeepSeek Harness\resources\runtime\pnpm\bin\pnpm.cjs'),
    (Join-Path $env:ProgramFiles 'DeepSeek Harness\resources\runtime\pnpm\bin\pnpm.mjs')
  )
  foreach ($candidate in $candidates) {
    if ($candidate -and (Test-Path $candidate)) { return $candidate }
  }
  $onPath = Get-Command pnpm -ErrorAction SilentlyContinue
  if ($onPath) { return $onPath.Source }
  throw 'no pnpm found; pass -Pnpm <pnpm.mjs or pnpm.cmd>'
}

function Write-Manifest($json, $path) {
  $utf8 = New-Object System.Text.UTF8Encoding($false)
  $temporary = $path + '.tmp'
  [System.IO.File]::WriteAllText($temporary, (($json | ConvertTo-Json -Depth 10) + "`n"), $utf8)
  Move-Item -Force $temporary $path
}

function Backup($path, $tag) {
  if (-not (Test-Path $path)) { return }
  $stamp = (Get-Item $path).LastWriteTime.ToString('yyyyMMdd-HHmmss')
  Copy-Item $path "$path.$tag-$stamp" -Force
  Write-Host "  backed up -> $path.$tag-$stamp" -ForegroundColor DarkGray
}

# A `file:` spec for the profile manifest: forward slashes, no escaping surprises.
function FileSpec($dir) {
  return 'file:' + ($dir -replace '\\', '/')
}

$profileDir = Resolve-ProfileDir
$sourceDir = Resolve-SourceDir
$manifestPath = Join-Path $profileDir 'package.json'
$lockPath = Join-Path $profileDir 'pnpm-lock.yaml'
$depSpec = FileSpec $sourceDir

Write-Host "profile: $profileDir"
Write-Host "package: $sourceDir"
Write-Host ''

Write-Host '--- 1. the package tree must exist ---'
if (-not $Uninstall) {
  foreach ($required in @('package.json', 'index.js', 'client.js', 'cordis.patch.yml')) {
    $file = Join-Path $sourceDir $required
    if (-not (Test-Path $file)) { throw "package is missing $required ($file)" }
  }
  Write-Host "  present at $sourceDir" -ForegroundColor Green
}

$json = Get-Content $manifestPath -Raw | ConvertFrom-Json
$beforeBundles = @($json.dsh.profile.bundles)

if ($Uninstall) {
  Write-Host ''
  Write-Host '--- 2. remove the dependency and the bundle entry ---'
  if ($json.dependencies.PSObject.Properties.Name -contains $plugin) {
    $json.dependencies.PSObject.Properties.Remove($plugin)
    Write-Host "  dropped dependency $plugin"
  }
  $json.dsh.profile.bundles = @($beforeBundles | Where-Object { $_ -ne $plugin })
  Write-Host ('  bundles: ' + (@($json.dsh.profile.bundles) -join ', '))
  if ($DryRun) { Write-Host '--DryRun: nothing written'; exit 0 }
  Backup $manifestPath 'before-think-status-top'
  Write-Manifest $json $manifestPath
  Write-Host ''
  Write-Host '--- 3. materialise the removal ---'
  & (Resolve-NodeExe) (Resolve-Pnpm) --dir $profileDir install
  Write-Host ''
  Write-Host 'Removed. Reload the app (or restart it) to get the stock placement back.' -ForegroundColor Green
  exit 0
}

Write-Host ''
Write-Host '--- 2. declare the dependency (idempotent) ---'
$deps = $json.dependencies
if ($deps.PSObject.Properties.Name -contains $plugin) {
  $deps.$plugin = $depSpec
  Write-Host "  already declared; pinned to $depSpec"
} else {
  $deps | Add-Member -NotePropertyName $plugin -NotePropertyValue $depSpec -Force
  Write-Host "  added $plugin -> $depSpec"
}
if ($DryRun) {
  Write-Host ''
  Write-Host '--DryRun: would write the manifest, run pnpm install, then mount the bundle'
  exit 0
}
Backup $manifestPath 'before-think-status-top'
Backup $lockPath 'before-think-status-top'
Write-Manifest $json $manifestPath

Write-Host ''
Write-Host '--- 3. materialise the package tree ---'
& (Resolve-NodeExe) (Resolve-Pnpm) --dir $profileDir install
if ($LASTEXITCODE -ne 0) { throw "pnpm install failed with exit code $LASTEXITCODE" }

Write-Host ''
Write-Host '--- 4. mount the bundle (pnpm rewrites the manifest, so this is written last) ---'
$json = Get-Content $manifestPath -Raw | ConvertFrom-Json
if (-not ($json.dependencies.PSObject.Properties.Name -contains $plugin)) {
  $json.dependencies | Add-Member -NotePropertyName $plugin -NotePropertyValue $depSpec -Force
  Write-Host '  re-added the dependency pnpm dropped'
}
$bundles = @($json.dsh.profile.bundles)
if ($bundles -notcontains $plugin) {
  $json.dsh.profile.bundles = @($bundles + $plugin)
  Write-Host "  mounted $plugin"
} else {
  Write-Host '  already mounted'
}
Write-Host ('  bundles: ' + (@($json.dsh.profile.bundles) -join ', '))
Write-Manifest $json $manifestPath

Write-Host ''
Write-Host '--- 5. verify what landed on disk ---'
$verify = Get-Content $manifestPath -Raw | ConvertFrom-Json
$finalBundles = @($verify.dsh.profile.bundles)
if ($finalBundles -notcontains $plugin) { throw 'the plugin is not in the written bundle list' }
if (-not ($verify.dependencies.PSObject.Properties.Name -contains $plugin)) { throw 'the dependency was not written' }
$installed = Join-Path $profileDir "node_modules\$plugin"
if (-not (Test-Path $installed)) { throw "node_modules\$plugin is missing after install" }
foreach ($required in @('package.json', 'client.js', 'cordis.patch.yml')) {
  if (-not (Test-Path (Join-Path $installed $required))) { throw "installed tree is missing $required" }
}
Write-Host '  dependency, bundle entry and installed tree all present' -ForegroundColor Green
Write-Host ''
Write-Host 'Done. Reload the app window (or restart the app if the roster does not pick it up).' -ForegroundColor Green
Write-Host 'The running status line now shows in the process header, above the thinking text.'