# Changelog

## 1.0.0 — 2026-10-01

First public release.

- Mirrors the live running-status row (`[data-chat-running]`) into the running turn's vacant
  process seat, so `深度求索中，用时 X 秒…` sits above the thinking text again, as in 0.1.7.
- Falls back to the running process-group header when no seat is mounted, and releases everything
  (leaving the stock bottom row visible) when neither anchor is available.
- Keeps the bottom row in the accessibility tree via `clip`; the clone drops its live-region
  attributes so the announcement happens exactly once.
- Never writes into React-owned subtrees; compare-then-write updates; microtask-coalesced
  reconciliation; `try/catch` around `apply` so a failure can only mean "no effect".
- Portable Windows installer that discovers the profile directory, the checkout location and the
  app's bundled `node`/`pnpm`.