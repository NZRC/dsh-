// Client half of @local/dsh-think-status-top.
//
// DSH 0.2.0 moved the live 「深度求索中，用时 X…」 copy out of the Turn-process row and
// into a separate RunningStatus row at the very bottom of the transcript:
// `TurnProcessNodeView` now returns null while the Turn is open, and `ChatView`
// renders `<RunningStatus>` *after* the node list. 0.1.7 kept that copy in the
// Turn-process row, i.e. above the reasoning content.
//
// The slot that row used to occupy still exists: every Turn's process controller is
// still emitted as a flow seat (`[data-chat-flow-kind="turn-process"]`), its node
// view simply renders nothing until the Turn closes — which is why ui-chat's own
// stylesheet carries
// `.fq8vsa_flowItem:is(:empty,:has(>[data-slot="conversation.chat.node"]:empty)){height:0}`
// and gives a *visible* turn-process seat a 16px gap below it. This plugin parks a
// copy of the running row in that vacant seat, so the running copy sits exactly where
// 0.1.7 put it: at the top of the Turn's process, above the thinking content.
//
// Two rules keep it safe:
//   1. it never writes into DOM React owns — the copy is our own cloned subtree, put
//      into a container React currently renders nothing into (`null` children
//      reconcile to no DOM operations at all), and removed again on release;
//   2. it acts only while a run is live and the seat is still vacant, and releases
//      everything otherwise — e.g. when the live Turn is virtualized away or the
//      container is taken — leaving the stock bottom row visible.
// A secondary anchor mirrors the same copy into the live process-group header label
// for the case where no vacant seat is mounted; it writes the text node React already
// created, so React's own updates still win once the Turn closes.
window.__ModuleLoader__.load({
	id: '@local/dsh-think-status-top',
	factory: (require) => {
		var module = { exports: {} };
		var exports = module.exports;

		/** Plugin identity: stylesheet key, attribute namespace, log prefix. */
		var NS = '@local/dsh-think-status-top';
		/** Identifies the injected stylesheet so a reload replaces instead of stacks. */
		var STYLE_ID = NS + '/think-status-top.css';
		/** Set on <html> only while the running copy is parked, alongside the anchor used. */
		var PLACED = 'data-dsh-think-status';
		var ANCHOR = 'data-dsh-think-status-anchor';
		/** Marks the header button carrying the mirrored copy (secondary anchor). */
		var HEADER = 'data-dsh-think-status-header';
		/** Marks our cloned running row (primary anchor). */
		var COPY = 'data-dsh-think-status-copy';
		/** The only value PLACED takes while the copy is parked. */
		var MOVED = 'moved';

		/** The live running row: the stock home of the running copy, at the transcript bottom. */
		var RUNNING_ROW = '[data-chat-running]';
		/** A Turn's process controller seat; its node view renders null while the Turn is open. */
		var SEAT = '[data-chat-flow-kind="turn-process"]';
		/** The chat-node slot a seat renders into; the seat itself is the fallback container. */
		var SLOT = '[data-slot="conversation.chat.node"]';
		/** Live process-group headers, tagged with their current activity. */
		var GROUP_HEADER = 'button[data-process-activity]';
		/** Only a still-running header holds an active TextShimmer. */
		var ACTIVE_SHIMMER = '[data-shimmer]';
		/** TextShimmer carries its own copy of the text in this attribute (the sweep). */
		var SHIMMER_TEXT = 'data-shimmer-text';

		/**
		 * The injected stylesheet. Two jobs: take the stock bottom row out of the visual
		 * flow while our copy is parked (with `clip`, not `display:none`, so its
		 * `aria-live` announcement survives), and dress the secondary anchor's header in
		 * the running row's own colour and shimmer tokens.
		 */
		var CSS = [
			'html[' + PLACED + "='" + MOVED + "'] " + RUNNING_ROW + ' {',
			'  position: absolute !important;',
			'  width: 1px !important;',
			'  height: 1px !important;',
			'  margin: 0 !important;',
			'  padding: 0 !important;',
			'  border: 0 !important;',
			'  overflow: hidden !important;',
			'  clip: rect(0 0 0 0) !important;',
			'  clip-path: inset(50%) !important;',
			'  white-space: nowrap !important;',
			'}',
			GROUP_HEADER + '[' + HEADER + '] {',
			'  --dsw-alias-label-shimmer: var(--dsw-alias-label-deep-diving-shimmer);',
			'  color: var(--dsw-alias-label-deep-diving);',
			'  font-variant-numeric: tabular-nums;',
			'}'
		].join('\n');

		/** Install the stylesheet once; safe to call repeatedly. */
		function installStyles() {
			if (document.querySelector('style[data-plugin-css=' + JSON.stringify(STYLE_ID) + ']') !== null) return;
			var tag = document.createElement('style');
			tag.dataset.plugin = NS;
			tag.dataset.pluginCss = STYLE_ID;
			tag.textContent = CSS;
			document.head.appendChild(tag);
		}

		/** Remove the stylesheet again (plugin disposal). */
		function removeStyles() {
			var tag = document.querySelector('style[data-plugin-css=' + JSON.stringify(STYLE_ID) + ']');
			if (tag !== null && tag.parentNode !== null) tag.parentNode.removeChild(tag);
		}

		/** Write an attribute only when it changes, so we never observe ourselves. */
		function setAttribute(element, name, value) {
			if (element.getAttribute(name) !== value) element.setAttribute(name, value);
		}

		/** Remove an attribute only when it is present. */
		function clearAttribute(element, name) {
			if (element.getAttribute(name) !== null) element.removeAttribute(name);
		}

		/**
		 * Collect the text nodes a reader actually sees under `root`.
		 *
		 * An active TextShimmer renders its copy twice: once for the reader and once
		 * inside an `aria-hidden` `inert` sweep decoration. Skipping hidden subtrees
		 * therefore yields exactly the visible copy, and keeps the running row's visually
		 * hidden `role="status"` announcement out of the result.
		 *
		 * @param root - element to scan.
		 * @returns visible, non-blank text nodes in document order.
		 */
		function visibleTextNodes(root) {
			var found = [];
			var walk = (node) => {
				var children = node.childNodes;
				for (var i = 0; i < children.length; i += 1) {
					var child = children[i];
					if (child.nodeType === 3) {
						if (String(child.nodeValue).trim() !== '') found.push(child);
						continue;
					}
					if (child.nodeType !== 1) continue;
					if (child.hasAttribute('aria-hidden') || child.hasAttribute('inert') || child.hidden) continue;
					walk(child);
				}
			};
			walk(root);
			return found;
		}

		/**
		 * Read the localized running copy ("深度求索中，用时 12 秒…") from a running row.
		 *
		 * The row is an active TextShimmer, so the sweep decoration already carries the
		 * exact string; the visible text node is the fallback.
		 *
		 * @param row - a running row, stock or cloned.
		 * @returns the copy, or an empty string when there is nothing to park yet.
		 */
		function readRunningCopy(row) {
			var marked = row.querySelector('[' + SHIMMER_TEXT + ']');
			if (marked !== null) {
				var value = marked.getAttribute(SHIMMER_TEXT);
				if (value !== null && value.trim() !== '') return value;
			}
			var nodes = visibleTextNodes(row);
			if (nodes.length === 0) return '';
			return String(nodes[nodes.length - 1].nodeValue).trim();
		}

		/**
		 * Write the running copy into a subtree we own, or into a header label whose text
		 * node React owns: the visible text node is updated in place and shimmer
		 * decorations follow through their attribute, so the sweep keeps matching the text.
		 *
		 * @param root - our cloned row, or a header whose text node React owns.
		 * @param text - localized running copy to show.
		 */
		function writeCopy(root, text) {
			var nodes = visibleTextNodes(root);
			if (nodes.length !== 0) {
				var label = nodes[nodes.length - 1];
				if (String(label.nodeValue) !== text) label.nodeValue = text;
			}
			var decorated = root.querySelectorAll('[' + SHIMMER_TEXT + ']');
			for (var i = 0; i < decorated.length; i += 1) {
				if (decorated[i].getAttribute(SHIMMER_TEXT) !== text) decorated[i].setAttribute(SHIMMER_TEXT, text);
			}
		}

		/**
		 * A container is vacant when React renders no content into it. Blank wrappers are
		 * tolerated; anything a rendered row would carry (its button, its turn-process
		 * markers, its glyph) makes it occupied.
		 *
		 * @param box - candidate container.
		 * @returns whether the copy may be parked there.
		 */
		function isVacant(box) {
			return String(box.textContent).trim() === '' && box.querySelector('button,[data-turn-process],svg,img') === null;
		}

		/**
		 * The container a seat renders its node into: the chat-node slot when present
		 * (the renderer wraps outlets in `div[data-slot]`, laid out with `display:contents`),
		 * the seat itself otherwise.
		 *
		 * @param seat - a process seat.
		 * @returns the container, or null when the seat already holds a rendered row.
		 */
		function boxOf(seat) {
			var slot = seat.querySelector(':scope > ' + SLOT) || seat.querySelector(SLOT);
			if (slot === null) return isVacant(seat) ? seat : null;
			return isVacant(slot) ? slot : null;
		}

		/**
		 * Find the live Turn's process seat and the container to park the copy in.
		 *
		 * A closed Turn's seat holds its rendered summary row; only the running Turn's
		 * seat is vacant, so scanning backwards finds the live one and never an older
		 * Turn's. A virtualized-away seat simply yields null.
		 *
		 * @returns the seat and its container, or null when no vacant seat is mounted.
		 */
		function vacantSeat() {
			var seats = document.querySelectorAll(SEAT);
			for (var i = seats.length - 1; i >= 0; i -= 1) {
				var seat = seats[i];
				if (seat.hasAttribute('hidden')) continue;
				var box = boxOf(seat);
				if (box !== null) return { seat: seat, box: box };
			}
			return null;
		}

		/**
		 * The running Turn's process-group header, used only when no seat is available.
		 *
		 * A completed Turn's header is rendered without an active shimmer, so the last
		 * header still holding one is the live group.
		 *
		 * @returns the live header button, or null when it is not mounted.
		 */
		function liveHeader() {
			var headers = document.querySelectorAll(GROUP_HEADER);
			for (var i = headers.length - 1; i >= 0; i -= 1) {
				if (headers[i].querySelector(ACTIVE_SHIMMER) !== null) return headers[i];
			}
			return null;
		}

		/** Where the copy is parked right now. */
		var state = { seat: null, box: null, copy: null, header: null };

		/** Drop our cloned row (if any) and forget its container. */
		function dropCopy() {
			if (state.copy !== null && state.copy.parentNode !== null) state.copy.parentNode.removeChild(state.copy);
			state.copy = null;
			state.box = null;
			state.seat = null;
		}

		/** Drop the secondary anchor's header override. */
		function dropHeader() {
			if (state.header !== null) state.header.removeAttribute(HEADER);
			state.header = null;
		}

		/** Leave the running copy in its stock place: no clone, no override, no gating. */
		function release() {
			dropCopy();
			dropHeader();
			clearAttribute(document.documentElement, PLACED);
			clearAttribute(document.documentElement, ANCHOR);
		}

		/**
		 * Clone the running row into a vacant container.
		 *
		 * The clone keeps the row's own classes, so it inherits the running colour, the
		 * shimmer and the whale animation from the shipped stylesheet. What must not be
		 * cloned: the running-row marker (it would shadow the stock row for our own
		 * lookups), React's generated ids, and the live-region semantics — the stock row
		 * keeps doing the announcing.
		 *
		 * @param seat - the process seat that owns the container.
		 * @param box - the vacant container to fill.
		 * @param row - the stock running row to clone.
		 */
		function mountCopy(seat, box, row) {
			var copy = row.cloneNode(true);
			copy.removeAttribute('data-chat-running');
			var identified = copy.querySelectorAll('[id]');
			for (var i = 0; i < identified.length; i += 1) identified[i].removeAttribute('id');
			var announced = copy.querySelectorAll('[role="status"],[aria-live]');
			for (var j = 0; j < announced.length; j += 1) {
				announced[j].removeAttribute('role');
				announced[j].removeAttribute('aria-live');
				announced[j].removeAttribute('aria-atomic');
				announced[j].setAttribute('aria-hidden', 'true');
			}
			copy.setAttribute(COPY, '');
			box.appendChild(copy);
			state.seat = seat;
			state.box = box;
			state.copy = copy;
		}

		/**
		 * The container to park the copy in: the one already in use while React still
		 * renders nothing else there, otherwise the vacant seat the live Turn is on.
		 *
		 * @returns the seat and its container, or null.
		 */
		function target() {
			if (state.box !== null && state.copy !== null && state.box.isConnected && state.seat !== null && state.seat.isConnected) {
				if (state.seat.hasAttribute('hidden')) return null;
				if (state.box.childElementCount === 1 && state.box.firstElementChild === state.copy) return { seat: state.seat, box: state.box };
				dropCopy();
			}
			return vacantSeat();
		}

		/** Record where the copy ended up, so CSS can gate on it and a console check can read it. */
		function markPlaced(anchor) {
			setAttribute(document.documentElement, PLACED, MOVED);
			setAttribute(document.documentElement, ANCHOR, anchor);
		}

		/**
		 * Reconcile the DOM with the wanted placement: park the running copy in the live
		 * Turn's process seat while a Turn runs, fall back to the live group header when no
		 * seat is mounted, and otherwise release everything — leaving the stock bottom row
		 * in place so the running state is never hidden without a visible replacement.
		 */
		function sync() {
			var row = document.querySelector(RUNNING_ROW);
			if (row === null) {
				release();
				return;
			}
			var text = readRunningCopy(row);
			if (text === '') {
				release();
				return;
			}
			var seat = target();
			if (seat !== null) {
				if (state.copy === null || state.box !== seat.box) {
					dropCopy();
					mountCopy(seat.seat, seat.box, row);
				}
				writeCopy(state.copy, text);
				dropHeader();
				markPlaced('seat');
				return;
			}
			var header = liveHeader();
			if (header !== null) {
				dropCopy();
				if (state.header !== null && state.header !== header) dropHeader();
				state.header = header;
				setAttribute(header, HEADER, '');
				writeCopy(header, text);
				markPlaced('header');
				return;
			}
			release();
		}

		/** Coalesce a burst of mutations into one reconcile at the next microtask. */
		var scheduled = false;
		function schedule() {
			if (scheduled) return;
			scheduled = true;
			Promise.resolve().then(() => {
				scheduled = false;
				try {
					sync();
				} catch (error) {
					console.error('[' + NS + '] sync failed:', error);
				}
			});
		}

		/** No client services are required: the placement only needs the page's DOM. */
		exports.inject = [];

		/**
		 * Mount the placement for as long as the entry is active. Everything is guarded: a
		 * client entry whose apply throws can take the whole web boot down with it.
		 */
		exports.apply = function apply(ctx) {
			ctx.effect(() => {
				var observer = null;
				var timer = null;
				try {
					installStyles();
					observer = new MutationObserver(schedule);
					observer.observe(document.documentElement, {
						childList: true,
						subtree: true,
						characterData: true,
						attributes: true,
						attributeFilter: ['data-shimmer', 'hidden', SHIMMER_TEXT, 'data-chat-running']
					});
					// Safety net for state a mutation record cannot deliver (a seat
					// re-mounted while the run continues, a virtualized window sliding).
					timer = setInterval(schedule, 1000);
					sync();
				} catch (error) {
					console.error('[' + NS + '] failed to start; leaving the stock placement:', error);
				}
				return () => {
					if (observer !== null) observer.disconnect();
					if (timer !== null) clearInterval(timer);
					release();
					removeStyles();
				};
			}, NS + ': running status placement');
		};

		return module.exports;
	}
});