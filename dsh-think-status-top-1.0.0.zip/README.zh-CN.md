# dsh-think-status-top

**把运行中的状态行放回回合顶部。** DSH 0.2.0 把「**深度求索中，用时 X 秒…**」从运行中回合的过程标题行
挪到了整个对话列的最底部；这个插件把它改回 0.1.7 的位置——过程标题行，也就是思考内容的上方。

它是一个**纯浏览器侧的 DSH 客户端插件**：不动 `app.asar`、不动 `exe`、不破坏签名与完整性校验。

![license](https://img.shields.io/badge/license-MIT-blue)
![platform](https://img.shields.io/badge/platform-dsh%20web%20%2F%20desktop-lightgrey)
![dsh](https://img.shields.io/badge/dsh-%E2%89%A50.2.0-blueviolet)

> English: [README.md](README.md)

---

## 问题

回合运行期间，DSH 0.2.0 把实时状态行渲染在整个节点列表**之后**，于是它落在对话列最底部，离它所描述的
思考内容很远。0.1.7 把这份文案放在回合的过程行里。

```
        0.2.0 原生                            装了这个插件
┌────────────────────────────────┐   ┌────────────────────────────────┐
│ ▸ 已完成工作 · 用时 12 秒       │   │ ▾ 深度求索中，用时 3 秒…        │ ← 挪到这里
│   (思考内容)                    │   │   (思考内容)                    │
│   (工具调用)                    │   │   (工具调用)                    │
│                                │   │                                │
│ ⠋ 深度求索中，用时 3 秒…        │ ←   │   (底部那一行：视觉上不可见，   │
└────────────────────────────────┘   │    读屏仍然播报)                │
                                     └────────────────────────────────┘
```

## 安装

插件装进一个 **DSH profile**（桌面端是 `~/.dsh/profiles/desktop`，`dsh web` 是
`~/.dsh/profiles/web`）。

### Windows：一条命令

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1

# 只看会做什么，不写盘
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1 -DryRun

# 卸载（移除依赖 + bundle 记录，并重新 pnpm install）
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1 -Uninstall
```

脚本会自动找到 profile 目录、本仓库自己的位置，以及桌面端自带的 `node` / `pnpm`。识别不了时可以覆盖：
`-Profile <目录>`、`-Source <目录>`、`-Node <node.exe>`、`-Pnpm <pnpm.mjs|pnpm.cmd>`。

装完需要**刷新窗口**（`Ctrl+R`）；如果插件名册没重新组装，就重启一下应用。

### 其它平台：手动三步

安装一个 DSH 客户端插件就是三件事，**顺序不能变**——`pnpm install` 会重写 profile 清单并丢掉第三方
bundle 记录，所以 bundle 记录必须最后写：

1. 在 `<profile>/package.json` 里声明依赖（本地检出，或本仓库）：

   ```json
   "dependencies": {
     "@local/dsh-think-status-top": "file:/绝对路径/dsh-think-status-top"
   }
   ```

   （也可以写 `"github:<owner>/dsh-think-status-top"`，直接从 GitHub 安装。）

2. 落地到 `node_modules`：

   ```sh
   node <...>/pnpm/bin/pnpm.mjs --dir <profile> install
   # 或者直接：pnpm --dir <profile> install
   ```

3. 把包名**追加**到 `<profile>/package.json` 的 bundle 列表：

   ```json
   "dsh": { "profile": { "bundles": [ "...", "@local/dsh-think-status-top" ] } }
   ```

然后刷新窗口。

### 确认它生效了

- 运行中的状态行出现在**运行中回合的过程标题行**，位于思考内容上方。
- DevTools 里 `<html>` 带 `data-dsh-think-status="moved"` 和
  `data-dsh-think-status-anchor="seat"`（走兜底路径时是 `"header"`）。
- 注入的样式表是 `style[data-plugin-css="@local/dsh-think-status-top/think-status-top.css"]`。

## 改了什么（行为）

| | 0.1.7（旧） | 0.2.0 原生 | 装了本插件 |
|---|---|---|---|
| 运行中「深度求索中，用时 X」 | 过程标题行（思考内容上方） | 对话列最底部 | **过程标题行（上方）** |
| 顶部标题原文案（正在分析请求／正在调用工具） | 不存在 | 显示 | 被运行文案取代（= 旧版行为） |
| 底部的运行行 | 不存在 | 显示 | 视觉上不可见，但**保留在无障碍树里**（`aria-live` 仍在播报） |

额外细节：

- 镜像文案直接取自底部那一行本身，所以**语言、用时格式、每秒刷新**都是原生的，不重复实现。
- 运行中的分组被虚拟化滚出屏幕时（这时没有任何顶部位置可放），插件会**自动恢复显示底部那一行**，
  不会出现「两边都没有」的空档。
- 只有「运行中」才会介入：回合结束后标题仍由 DSH 自己渲染（已完成工作 · 用时 X），插件不再写入。

## 为什么不能像以前那样直接改 app.asar

0.2.0 的官方桌面端**开启了 ASAR 完整性校验**：

| 证据 | 值 |
|---|---|
| exe 内的 Windows 资源 | `INTEGRITY` / `ELECTRONASAR` |
| 资源里记录的 asar 头部哈希 | `c8b9581d573fdda06c1d5fedd8c3e0535b09b2cddea3aba5555e24f9faf58355` |
| 实测 `SHA256(asar 头部 JSON)` | 与上面**完全一致** |

也就是说：改 `app.asar`（哪怕是等长覆盖）会让应用**下次启动直接被强制退出**；要绕过得先翻掉 exe 的
`EnableEmbeddedAsarIntegrityValidation` fuse（同时作废数字签名），并且每次应用升级都要重来一次。
所以这次走官方支持的插件路线。

## 它是怎么做到的

旧位置其实还在：每个回合的过程控制器仍然作为一个 flow seat 输出
（`[data-chat-flow-kind="turn-process"]`），只是回合未结束时它的 node view 渲染 `null`——这正是
`ui-chat` 样式表里为空 flow item 准备了 `height: 0` 规则的原因。插件就把**运行行的克隆**停进这个空位。

| 目标 | 选择器 | 说明 |
|---|---|---|
| 底部运行行 | `[data-chat-running]` | `ChatView` 里 `RunningStatus` 的根，是聊天列的直接子元素，也是文案来源 |
| 它的文案 | 行内 `[data-shimmer-text]` | 激活态 `TextShimmer` 会在装饰副本上带完整字符串 |
| 空位 | `[data-chat-flow-kind="turn-process"]` 且其 chat-node 插槽为空 | 克隆停靠的位置 |
| 运行中的分组标题 | `button[data-process-activity]` 且内部含 `[data-shimmer]` | 兜底锚点；已结束回合的标题没有活跃 shimmer，用它区分 |

写法上刻意保守：

1. **绝不写入 React 持有的 DOM。** 主锚点是 React 当前不渲染任何内容的容器（`null` children 不会产生
   任何 DOM 操作），放进去的是我们自己克隆的子树，释放时移除；兜底锚点只改 React 已经建好的文本节点，
   所以回合结束时 React 的更新照旧生效。
2. **只在「运行中」且空位仍然空着时介入**，其余情况全部释放（被虚拟化滚走、容器被占用、回合结束），
   宁可保留原生的底部行，也不让运行状态从画面上消失。
3. 隐藏底部行用 `clip`（不是 `display:none`），读屏播报保留；克隆体去掉了 `role="status"`/`aria-live`，
   所以**只播报一次**。
4. 所有写入都先比较再写（避免自己触发自己的 MutationObserver），同一帧内的多次变更用微任务合并。
   `apply` 全程 `try/catch`：插件出错最多是「没效果」，不会把 web boot 带崩。

## 想换个效果时改哪里

| 想要的效果 | 改法 |
|---|---|
| 顶部**同时**保留活动文案（深度求索中 · 正在调用工具…） | `client.js` 的 `writeCopy` 里写成 `text + ' · ' + 原文案` |
| 彻底不要底部那行（连读屏也不播报） | `CSS` 里的 `clip` 版隐藏换成 `display: none !important` |
| 连图标/chevron 也去掉 | 在 `CSS` 里补 `... [data-step-process-icon] { display: none; }` |

`file:` 依赖是拷贝不是软链，改完要同步一次（把路径换成本机 profile 目录）再刷新窗口：

```powershell
Copy-Item ".\client.js" "$env:USERPROFILE\.dsh\profiles\desktop\node_modules\@local\dsh-think-status-top\client.js" -Force
```

## 排查

| 现象 | 先看什么 |
|---|---|
| 没有任何变化 | 先刷新窗口；再确认 `dsh.profile.bundles` 里有它，且 profile 的 `node_modules/@local/dsh-think-status-top` 存在 |
| DSH 升级后失效 | 插件锚在 DOM 上，且**失败时保持原样**：锚点变了它就静默不做事，底部行照旧。更新插件，或带着新 DOM 提 issue |
| 控制台出现 `[dsh-think-status-top] sync failed` | 协调逻辑抛错了；插件保持原生位置并把错误打出来 |
| 位置有遮挡/重叠 | 那个 seat 由 DSH 自己的 `ui-chat` 样式表控制，看看是否有别的 UI 插件改了 flow seat 样式 |
| 想变回底部那一行 | 用 `-Uninstall` 再跑一次安装脚本 |

## 兼容性

- DSH **0.2.0**，桌面端与 `dsh web` 都适用（改动面是 `packages/client/ui-chat`）。
- 插件声明 `engines.dsh = ">=0.2.0"`。它按构造就是版本无关的——读取 DSH 渲染出来的运行行再镜像出去——
  所以最坏情况只是「不生效」，不会弄坏回合。
- Windows / macOS / Linux 都可以用；平台只影响那个 PowerShell 安装脚本。

## 文件

| 文件 | 说明 |
|---|---|
| `client.js` | 全部行为：MutationObserver、锚点、克隆、样式表 |
| `index.js` | 宿主半边；刻意留空（只有 `apply`），让包能作为 Cordis 插件参与组装 |
| `cordis.patch.yml` | 以包名为模块 id 挂载这个客户端模块 |
| `package.json` | `dsh.client` / `dsh.bundle` 声明 |
| `install-think-status-top.ps1` | 自动识别 profile 的安装/卸载脚本（Windows） |

## 许可证

MIT，见 [LICENSE](LICENSE)。