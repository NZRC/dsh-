# dsh-think-status-top

**Put the live running-status line back on top of the turn.** DSH 0.2.0 moved
`深度求索中，用时 X 秒…` / *"Deep diving… Xs"* out of the running turn's process header and
pinned it to the very bottom of the transcript; this plugin puts it back where 0.1.7 had it —
in the process-group header, directly above the thinking text.

It is a **browser-side DSH client plugin**. No `app.asar` patching, no `exe` edits, no broken
signature or integrity validation.

![license](https://img.shields.io/badge/license-MIT-blue)
![platform](https://img.shields.io/badge/platform-dsh%20web%20%2F%20desktop-lightgrey)
![dsh](https://img.shields.io/badge/dsh-%E2%89%A50.2.0-blueviolet)

---

## The problem

While a turn is running, DSH 0.2.0 renders the live status row *after* the whole node list, so it
sits at the bottom of the conversation column — far away from the thinking text it belongs to.
0.1.7 kept that copy inside the turn's process row.

```
        0.2.0 stock                          with this plugin
┌────────────────────────────────┐   ┌────────────────────────────────┐
│ ▸ 已完成工作 · 用时 12 秒       │   │ ▾ 深度求索中，用时 3 秒…        │ ← moved up here
│   (thinking text)              │   │   (thinking text)              │
│   (tool calls)                 │   │   (tool calls)                 │
│                                │   │                                │
│ ⠋ 深度求索中，用时 3 秒…        │ ←   │   (bottom row: visually gone,  │
└────────────────────────────────┘   │    still announced to readers) │
                                     └────────────────────────────────┘
```

## Install

The plugin is installed into a **DSH profile** (`~/.dsh/profiles/desktop` for the desktop app,
`~/.dsh/profiles/web` for `dsh web`).

### Windows: one command

```powershell
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1

# see what it would do, without writing anything
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1 -DryRun

# remove it again
powershell -NoProfile -ExecutionPolicy Bypass -File .\install-think-status-top.ps1 -Uninstall
```

The script discovers the profile directory, this checkout's own location, and the `node`/`pnpm`
runtime the desktop app carries. Override any of them when detection cannot know better:
`-Profile <dir>`, `-Source <dir>`, `-Node <node.exe>`, `-Pnpm <pnpm.mjs|pnpm.cmd>`.

Reload the window afterwards (`Ctrl+R`); if the plugin roster was not re-composed, restart the app.

### Any platform: three edits by hand

Installing a DSH client plugin is exactly three things, and the order matters — `pnpm install`
rewrites the profile manifest and drops third-party bundle entries, so the bundle entry is
written last:

1. In `<profile>/package.json`, declare the dependency (a local checkout, or this Git repo):

   ```json
   "dependencies": {
     "@local/dsh-think-status-top": "file:/absolute/path/to/dsh-think-status-top"
   }
   ```

   (Alternative: `"github:<owner>/dsh-think-status-top"` to install straight from GitHub.)

2. Materialise it:

   ```sh
   node <...>/pnpm/bin/pnpm.mjs --dir <profile> install
   # or simply: pnpm --dir <profile> install
   ```

3. Mount it by appending its name to the bundle list in `<profile>/package.json`:

   ```json
   "dsh": { "profile": { "bundles": [ "...", "@local/dsh-think-status-top" ] } }
   ```

Then reload the window.

### Verify it is live

- The running status line appears in the **process header of the running turn**, above the
  thinking text.
- In DevTools, `<html>` carries `data-dsh-think-status="moved"` together with
  `data-dsh-think-status-anchor="seat"` (or `"header"` on the fallback path).
- The injected stylesheet is `style[data-plugin-css="@local/dsh-think-status-top/think-status-top.css"]`.

## What changes

| | 0.1.7 | 0.2.0 stock | with this plugin |
|---|---|---|---|
| live `深度求索中，用时 X…` | process header, above the thinking text | bottom of the transcript | **process header, above the thinking text** |
| header's own copy (`正在分析请求` / `正在调用工具`) | — | shown | replaced by the running copy (0.1.7 behaviour) |
| the bottom row | — | shown | not visible, but **kept in the accessibility tree** (`aria-live` still announces it) |

Details worth knowing:

- The mirrored text is taken **from the bottom row itself**, so language, duration format and the
  once-per-second refresh stay native — nothing is re-implemented.
- When the running turn's seat is virtualized off-screen (so there is no top position to use at
  all), the plugin **restores the stock bottom row** instead of leaving nothing visible.
- It only intervenes while a turn is *running*. Once the turn closes, the header is DSH's own
  rendering again (`已完成工作 · 用时 X`) and the plugin stops writing to it.

## Why not just patch `app.asar`?

Because 0.2.0's desktop build validates it:

| evidence | value |
|---|---|
| Windows resources in the `exe` | `INTEGRITY` / `ELECTRONASAR` |
| asar header hash recorded there | `c8b9581d573fdda06c1d5fedd8c3e0535b09b2cddea3aba5555e24f9faf58355` |
| measured `SHA256(asar header JSON)` | identical |

Editing `app.asar` — even an equal-length overwrite — makes the app exit on the next launch.
Avoiding that means flipping the `EnableEmbeddedAsarIntegrityValidation` fuse (invalidating the
code signature) and redoing it after every update. This plugin takes the supported route instead:
DSH's own client-plugin mechanism.

## How it works

The slot the running row used to occupy is still in the DOM. Every turn's process controller is
still emitted as a flow seat (`[data-chat-flow-kind="turn-process"]`), but its node view renders
`null` while the turn is open — which is why `ui-chat`'s stylesheet carries a
`height: 0` rule for an empty flow item. That vacant seat is exactly where 0.1.7's copy lived, so
the plugin parks a **clone of the live row** there.

| target | selector | meaning |
|---|---|---|
| the live bottom row | `[data-chat-running]` | `RunningStatus`' root in `ChatView`; the copy's source |
| its text | `[data-shimmer-text]` on the row | an active `TextShimmer` carries the full string in this attribute |
| the vacant seat | `[data-chat-flow-kind="turn-process"]` whose chat-node slot is empty | where the copy is parked |
| the running group header | `button[data-process-activity]` containing `[data-shimmer]` | fallback anchor; a closed turn's header has no active shimmer |

Safety rules, deliberately conservative:

1. **Never write into DOM React owns.** The primary anchor is a container React currently renders
   nothing into (`null` children reconcile to no DOM operations at all) and receives our own cloned
   subtree, removed again on release. The fallback anchor only rewrites a text node React already
   created, so React's own update still wins when the turn closes.
2. **Act only while a run is live and the seat is still vacant**, and release everything otherwise
   (virtualized away, container re-used, turn finished) — the stock bottom row stays in place
   rather than the running state disappearing from the screen.
3. Hidden with `clip`, not `display: none`, so screen readers keep announcing the bottom row —
   exactly once, since the clone drops its `role="status"`/`aria-live` attributes.
4. Every write is compare-then-write, so the plugin never reacts to its own mutations, and a burst
   of mutations is coalesced into one reconcile on the next microtask. `apply` is wrapped in
   `try/catch`: the worst case is "no effect", never a broken web boot.

## Tuning

| want | change |
|---|---|
| keep both texts in the header (`深度求索中 · 正在调用工具`) | in `client.js`, write `text + ' · ' + original` in `writeCopy` |
| take the bottom row out entirely, screen readers included | in `CSS`, swap the `clip` block for `display: none !important` |
| drop the icon/chevron of the mirrored row too | add `... [data-step-process-icon] { display: none; }` to `CSS` |

After editing a `file:` dependency, re-sync the installed copy (a `file:` dependency is a copy,
not a symlink) and reload:

```powershell
Copy-Item ".\client.js" "$env:USERPROFILE\.dsh\profiles\desktop\node_modules\@local\dsh-think-status-top\client.js" -Force
```

## Troubleshooting

| symptom | what to check |
|---|---|
| nothing changed | reload the window; then confirm the plugin is in `dsh.profile.bundles` and that `node_modules/@local/dsh-think-status-top` exists in the profile |
| no effect after a DSH upgrade | the plugin is DOM-anchored and **fails open**: if the anchors change it silently does nothing and the stock bottom row stays. Update the plugin, or open an issue with the new DOM |
| the console shows `[dsh-think-status-top] sync failed` | the reconcile threw; the plugin keeps the stock placement and logs the error |
| the line overlaps something | the seat is styled by DSH's own `ui-chat` stylesheet — check whether another UI plugin re-styles the flow seat |
| I want the old bottom row back | run the installer with `-Uninstall` |

## Compatibility

- DSH **0.2.0** on the desktop app and on `dsh web` (the surface is `packages/client/ui-chat`).
- The plugin declares `engines.dsh = ">=0.2.0"`. It is version-agnostic by construction — it reads
  the running row DSH renders and mirrors it — so it cannot break a turn, only decline to act.
- Windows/macOS/Linux: the plugin is browser-side, so the platform only matters for the installer.

## Files

| file | what it is |
|---|---|
| `client.js` | the whole behaviour: MutationObserver, anchors, clone, stylesheet |
| `index.js` | host half; intentionally empty (`apply` only), so the package composes as a Cordis plugin |
| `cordis.patch.yml` | mounts the client module under the package name as its module id |
| `package.json` | `dsh.client` / `dsh.bundle` declarations |
| `install-think-status-top.ps1` | profile-aware installer / uninstaller (Windows) |

## License

MIT — see [LICENSE](LICENSE).